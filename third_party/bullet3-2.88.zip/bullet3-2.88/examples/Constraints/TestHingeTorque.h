#ifndef TEST_HINGE_TORQUE_H
#define TEST_HINGE_TORQUE_H

class CommonExampleInterface* TestHingeTorqueCreateFunc(struct CommonExampleOptions& options);

#endif  //TEST_HINGE_TORQUE_H
