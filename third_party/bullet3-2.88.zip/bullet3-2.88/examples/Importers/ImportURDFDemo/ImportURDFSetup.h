#ifndef IMPORT_URDF_SETUP_H
#define IMPORT_URDF_SETUP_H

class CommonExampleInterface* ImportURDFCreateFunc(struct CommonExampleOptions& options);

#endif  //IMPORT_URDF_SETUP_H
